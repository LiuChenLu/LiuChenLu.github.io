//////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// length.h
//	adds and subtracts the length denoted in feet and inches
//	excercise in overloading opeartors
//
////////////////////////////////////////////////////////////////////

#ifndef __LENGTH_H__
#define __LENGTH_H__
#include <iostream>
struct Length {
	int ft;
	int in;
};

Length operator+(const Length& , const Length& );
Length operator-(const Length& , const Length& );
Length operator+(const Length& , int );
Length operator-(const Length&, int );
Length operator+(int , const Length& );
Length operator-(int , const Length& );
std::ostream& operator<< (std::ostream &, const Length &);
std::istream& operator>> (std::istream &, Length &);

#endif

