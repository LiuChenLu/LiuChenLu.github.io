//////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// length.cc
//	adds and subtracts the length denoted in feet and inches
//	excercise in overloading opeartors
//
////////////////////////////////////////////////////////////////////

#include<iostream>
#include "length.h"

using std::cin;
using std::cout;
using std::endl;

// precondition: l is a valid Length
// returns: stream
// overloading >> to read in Length as two consequtive intergers for ft and in
std::istream& operator>> ( std::istream &stream, Length& l) {
	stream >> l.ft >> l.in;
	return stream;
}


// precondition: l is a valid Length
// returns: stream
// overloading << to write a Length l formated as: l.ft' l.in"
std::ostream& operator<< (std::ostream &stream, const Length& l) {
	return stream << l.ft << "' " << l.in << "\"";
}


// precondition: a and b are valid Length's
// return: Length
// overloading + to add two lengths
Length operator+ (const Length& a, const Length& b ) {
	Length c;
	c.ft = a.ft + b.ft + ( ( a.in + b.in ) / 12 );
	c.in = (a.in + b.in ) % 12;
	return c;
}


// precondition: a and b are valid Length's
// return: Length
// overloading - to subtract b from a
Length operator- (const Length& a , const Length& b) {
	Length d;
	
	// the carry from a.in-b.in need to be accounted for
	int carry = ( a.in - b.in ) / 12;
	// if carry is not positive, round down
	carry = ( a.in - b.in < 0 && carry * 12 != a.in - b.in)? carry = carry - 1 : carry;
	d.ft =  a.ft - b.ft + carry;
	
	d.in = (a.in - b.in + 12 ) % 12;                           
        
	return d;
}


// precondition: l is a valid length and i is a valid int
// return: Length
// overloading + to add a Length and a int
// the int i is interpreted as inches
Length operator+ (const Length& l , int i) {
	Length c;
	c.ft = l.ft + ( ( l.in + i ) / 12 );        
        c.in = (l.in + i ) % 12;                           
        return c;
}

// precondition: l is a valid length and i is a valid int
// return: Length
// overloading + to add a Length and a int
// the int i is interpreted as inches
// note: this function is very similar to the previous function
Length operator+ ( int i , const Length& l ) {
        Length c;
        c.ft = l.ft + ( ( l.in + i ) / 12 );          
        c.in = (l.in + i ) % 12;                              
        return c;
}


// precondition: l is a valid length and i is a valid int, l is longer than i
// return: Length                                             
// overloading - to subtract a int from a  Length 
// the int i is interpreted as inches
Length operator- (const Length& l , int i) {
        Length d;
       	
	// the carry from a.in-b.in need to be accounted for
        int carry = ( l.in - i ) / 12;
        // if carry is not positive, round down; else leave it be
        carry = ( l.in - i < 0 && carry * 12 != l.in - i)? carry = carry - 1 : carry;
        d.ft =  l.ft + carry;
 
        d.in = (l.in - i + 12) % 12;
        return d;
}


// precondition: l is a valid length and i is a valid int, i is longer than l
// return: Length                                             
// overloading - to subtract a Length from an int
// the int i is interpreted as inches
Length operator- (int i, const Length& l) {
        Length d;
 	
	// the carry from a.in-b.in need to be accounted for
        int carry = ( i - l.in ) / 12;
        // if carry is not positive, round down; else leave it be
        carry = ( i - l.in < 0 && carry * 12 != l.in - i)? carry = carry - 1 : carry;
        d.ft =  carry - l.ft;       
        
	d.in = (i-l.in) % 12;
        
	return d;
}

/* tests
#include <iostream>
#include <iomanip>
#include "length.h"

using namespace std;


int main()
{
        Length a, b, c, d;
        int x = 10;

        // read length from cin as two consecutive integers, 
        // for feet and inches, respectively.
        cin >> a >> b;
        
        // a = 2 ft 3 inch
        // b = 9 inches

        // add and/or subtract variables of type length
        c = a + b;
        cout << c << endl;

        c = a - b;
        cout << c << endl;      

        // add and/or subtract length variable with integers
        d = a + x;
        cout << d  << endl;
        
        d = a - x;
        cout << d << endl;

        d = x - b;
        cout << d << endl;
        
        d = x + b;
        cout << d  << endl;
        return 0;
}

~/cs246/a03$ g++ lmain2.cc length.cc
~/cs246/a03$ ./a.out
2 0 0 1
2' 1"
1' 11"
2' 10"
1' 2"
0' 9"
0' 11"

~/cs246/a03$ ./a.out
2 3 0 9
3' 0"
1' 6"
3' 1"
1' 5"
0' 1"
1' 7"

~/cs246/a03$ ./a.out
1 9 1 5
3' 2"
0' 4"
2' 7"
0' 11"
-1' 5"
2' 3"

///////////////////////////////////////////////////////////


*/
