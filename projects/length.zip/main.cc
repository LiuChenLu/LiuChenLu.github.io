//////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// main.cc
//	adds and subtracts the length denoted in feet and inches
//	excercise in overloading opeartors
//
//	some tests for length.cc and length.h
//
////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include "length.h"

using namespace std;

int main()
{
	Length a, b, c, d;
	int x = 10;
	
	// read length from cin as two consecutive integers, 
	// for feet and inches, respectively.
	cin >> a >> b;
	
	// a = 2 ft 3 inch
	// b = 9 inches

	// add and/or subtract variables of type length
	c = a + b;
	cout << c << endl;

	c = a - b;
	cout << c << endl;	

	// add and/or subtract length variable with integers
	d = a + x;
	cout << d  << endl;
	
	d = a - x;
	cout << d << endl;

	d = x - b;
	cout << d << endl;
	
	d = x + b;
	cout << d  << endl;
	return 0;
}

