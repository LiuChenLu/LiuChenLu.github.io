//////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// trie.h
//	preforms auto completion
//
// 	maintains a dictionary of available words, and use them to
//	autocomplete prefixes that you provide. words are assumed 
// 	to be all lower case.
//
//	excercise in working with trees
//
////////////////////////////////////////////////////////////////////

#ifndef __TRIE_H__
#define __TRIE_H__
#include <string>

// enumerate the characters of the alphabet
enum letters {a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z};

struct TrieNode {
    // NumChars is not stored as a static value so that the
    // dictionary can be easily changed to have more than 26
    // characters
    enum { Apostrophe = 26, NumChars = 27 };
    bool isWord;
    TrieNode *letters[NumChars];
    TrieNode() {
        isWord = false;
         for ( int i = 0; i < NumChars; i += 1 ) {
             letters[i] = NULL;
         } // for
    }
}; // TrieNode


// precondition: node is a TrieNode and word is a string
// returns nothing, prints nothing, deletes word as side effect
// adds word to the dictionary
void insert( TrieNode &node, std::string &word );

// precondition: node is a TrieNode and word is a string
// returns nothing, prints nothing
// removes word to the dictionary
void remove( const std::string &word );

// precondition: node is a TrieNode and fragment is a string
// returns nothing
// a helper function to complete, prints all valid words starting
// 	from node
void complete ( const std::string &fragment );

// precondition: true
// returns nothing, but may print to cout as side effect
// starts reading from standard input if cin is not eof
void startread ();

// precondition: true
// returns nothing, but may print to cout as side effect
// read from file and after the file has been read in full, read
// standard input again
void execute ( const std::string &filename );

// precondition: true
// returns nothing
// recursively delete the TrieNode dictionary's children
// called at the end of the using dictionary to free the memory
void deletedictionary();


#endif
