//////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// main.cc
//	preforms auto completion
//
// 	maintains a dictionary of available words, and use them to
//	autocomplete prefixes that you provide. words are assumed 
// 	to be all lower case.
//
//	excercise in working with trees
//
////////////////////////////////////////////////////////////////////
// 
// accepted commands
//
// + word
// adds word to the dictionary
// 
// - word
// removes word from the dictionary
// 
// ? word
// prints a list of possible autocompletions for word, in 
// alphabetical order
// 
// include filename
// Reads the file filename and executes the commands contained
// therein.
// 
////////////////////////////////////////////////////////////////////

#include<iostream>
#include<fstream>
#include<string>
#include "trie.h"

using std::getline;
using std::cin;
using std::cout;
using std::endl;
using std::string;

int main() {
	// start reading from standard input
	startread();

	// all of standard input has been read
	
	deletedictionary();

	return 0;
}

// tests
////////////////////////////////////////////////////////////////////
/*
~/Documents/cs246/a03/p3: $ $bash commands
~/Documents/cs246/a03/p3: $ g++ main.cc trie.h trie.cc
~/Documents/cs246/a03/p3: $ cat execute.cc
// sameple commands
+ ac
+ ad
+ aaa
+ af
+ ad
+ ae
? a
+ aa
? a
? b
+ lisa
+ mint
- aa
? a
~/Documents/cs246/a03/p3: $ ./a.out
+ aa
+ ab
? a
>aa ab 
include execute.cc
>aa aaa ab ac ad ae af 
>aa aaa ab ac ad ae af 
>aaa ab ac ad ae af 
>aaa ab ac ad ae af
+ lili
? li
>lili lisa
- lisa
? li
>lili 
*/
