// sample commands
+ ac
+ ad
+ aaa
+ af
+ ad
+ ae
? a
+ aa
? a
? b
+ lisa
+ mint
- aa
? a
