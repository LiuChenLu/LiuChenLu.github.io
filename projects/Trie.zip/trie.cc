//////////////////////////////////////////////////////////////////
//
//
// Liu Chen Lu
// 
// trie.cc
//	preforms auto completion
//
// 	maintains a dictionary of available words, and use them to
//	autocomplete prefixes that you provide. words are assumed 
// 	to be all lower case.
//
//	excercise in working with trees
//
////////////////////////////////////////////////////////////////////

#include<iostream>
#include<fstream>
#include<string>
#include"trie.h"

using std::getline;
using std::cin;
using std::cout;
using std::endl;
using std::string;

// setting up variables
////////////////////////////////////////////////////////////////////

// make a dictionary tree
struct TrieNode dictionary;

////////////////////////////////////////////////////////////////////

// precondition: node is a TrieNode and word is a string
// returns nothing, prints nothing, deletes word as side effect
// adds word to the dictionary
void insert( TrieNode &node, std::string &word ){
	if(word.begin() != word.end()) {
	// the word is not finished
		// put the character into word.letters
		letters l = (letters)*word.begin();
		int pos = l - 97;
		
		// cout << *word.begin() << " " << pos << endl;
		
		// if node.letters[pos] has not been initialized
		if (node.letters[pos] == NULL) {
			node.letters[pos] = new TrieNode;
		}
		
		// go to the next character by erasing one
		// character from the begining
		word.erase(0,1);
		insert (*(node.letters[pos]), word);
	} else { 
	// the word is finished
		node.isWord = true;
	}
}


// precondition: node is a TrieNode and word is a string
// returns a TrieNode pointer, deletes word as side effect
// returns a pointer to the TrieNode that word ends on
TrieNode* find( TrieNode &node, std::string word ) {
	if(word.begin() != word.end()) {
	// the word is not finished

		// get to the right position in the node.letters
		letters l = (letters)*word.begin();
		int pos = l - 97; //correct for the ascii value

		// if node.letters[pos] points to a valid TrieNode
		if (node.letters[pos] != NULL) {		
			// go to the next character by erasing one
			// character from the begining
			word.erase(0,1);
			return find (*(node.letters[pos]), word);
		} 
		
		// else node.letters[pos] does not point to a valid
		// TrieNode
		return NULL;
	}
	
	// else the word is finished and you are at the node of
	// interest
	return &node;
}


// precondition: node is a TrieNode and word is a string
// returns nothing, prints nothing
// removes word to the dictionary
void remove( const std::string &word ){
	TrieNode* result = find (dictionary, word);
	
	// if word is not found in node, then exit the function
	if ( result==NULL ) return;
	
	// else the word was found in the node, make it not a word
	result->isWord = false;
}


// precondition: node is a TrieNode and fragment is a string
// returns nothing
// a helper function to complete, prints all valid words starting
// 	from node
void completehelper ( TrieNode &node, const std::string fragment ) {
	if (node.isWord) cout << fragment << ' ';
	
	string fragmentcopy = fragment;
	// cout << fragmentcopy << "1" << endl;
	
	for (int i = 0; i < TrieNode::NumChars; i++) {
		// if for any of the i's there is node.letters[i] is
		// a valid pointer to a TrieNode
		if (node.letters[i] != NULL) {
	     		char c = (letters)(i + 97);// correct for ascii
			fragmentcopy.append(&c,1);
			
			completehelper(*(node.letters[i]), fragmentcopy);

			fragmentcopy = fragment;
			// cout << fragmentcopy << "1" << endl;
			
		}
		
	}
		
}


// precondition: node is a TrieNode and fragment is a string
// returns nothing
// prints a list of possible autocompletions for word, in
//	alphabetical order
// essentially preforms the function of [tab tab] in bash
void complete ( const std::string &fragment ){

	// go to where the end of the fragment in the tree
	TrieNode* result = find (dictionary, fragment);
	// fragment will not be erased by find since find uses a copy
	// of fragment
	
	// if fragment is not found in node, then exit the function
	// because there is nothing to print
	if ( result==NULL ) return;
	
	completehelper(*result, fragment);
	cout << endl;

}


// precondition: node is a TrieNode pointer
// returns nothing
// helper function to deletedictionary recursively delete node
void deletedictionaryhelper (TrieNode* node) {
	for (int i = 0; i < TrieNode::NumChars; i++) {
		
		// if for any of the i's  node.letters[i] is a 
		// valid pointer to a TrieNode
		if (node->letters[i] != NULL) {
	     		deletedictionaryhelper(node->letters[i]);
		}
	}
	
	delete node;
}


// precondition: true
// returns nothing
// recursively delete the TrieNode dictionary's children
// called at the end of the using dictionary to delete the memory
void deletedictionary () {

	// dictionary itself does not need to be deleted, since it
	// lives on the stack
	
	// delete dictionary's children

	for (int i = 0; i < TrieNode::NumChars; i++) {
		
		// if for any of the i's  dictionary.letters[i]
		// is a valid pointer to a TrieNode
		if (dictionary.letters[i] != NULL) {
	     		deletedictionaryhelper(dictionary.letters[i]);
		}
	}
}


// reading in commands
////////////////////////////////////////////////////////////////////

// really just need 1 strings to handle all situations, but 3 are
// for clarity
string command;
string file;
string word;


// precondition: true
// returns nothing, but may print to cout as side effect
// starts reading from standard input if cin is not eof
void startread (){
	while (cin) { 
                cin >> command;
                
               if (cin.fail()) break;
                
		if (command == "+") {
		//adds word to the dictionary
			cin >> word;
			insert(dictionary, word);
		} else if (command == "-") {
		// removes word from the dictionary
			cin >> word;
			remove(word);
		} else if (command == "?") {
		// prints a list of possible autocompletions for
		// word, in alphabetical order
			cin >> word;
			complete (word);
		} else if (command == "include") {
		// Reads the file filename and executes the
		// commands contained therein.
			cin >> file;
			execute(file);
		}
	}
}


// precondition: true
// returns nothing, but may print to cout as side effect
// read from file and after the file has been read in full, read
// standard input again
void execute(const std::string &filename){
	std::ifstream infile;
	infile.open (filename.c_str(), std::ifstream::in);
	
	if (infile.fail()) {
		cout<<"The file given was not found."<<endl;
		return;
	}
	
	while (infile.good()) {
                infile >> command;
		if (command == "+") {
		//adds word to the dictionary
			infile >> word;
			insert(dictionary, word);
		} else if (command == "-") {
		// removes word from the dictionary
			infile >> word;
			remove(word);
		} else if (command == "?") {
		// prints a list of possible autocompletions for
		// word, in alphabetical order
			infile >> word;
			complete (word);
		} else if (command == "include") {
		// Reads the file filename and executes the
		// commands contained therein.
			infile >> file;
			execute(file);
		}
	}
 
	// entire file has been read and excecuted

	// loop in the main function return to startread to 
	// continue reading cin if there are more commands in cin
}
