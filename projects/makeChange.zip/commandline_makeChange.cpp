////////////////////////////////////////////////////////////////////
//
// Liu Chen Lu
// 
// commandline_makeChange.cpp
//
// makeChange.app -number of coin types -list of coin values in
//	decreasing order -target/total
//
// given a denomination of coins from standard input, makes
//	change for a given value using the minimum number of coins
// 	using a greedy algorithm (assumed to work)
//
// same as makeChange.cpp except it takes its inputs from
// 	commandline rather than standard input
//
////////////////////////////////////////////////////////////////////

#include <iostream>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	
	// number of types of coins
	int nt = atoi(argv[1]);
	// the target value
	int tar = atoi(argv[argc - 1]);
	// partial sum of coins
	int ps = 0;
	// array of number of each type of coin used
	int numcoin [nt];

	// the position of the current coin being considered
	int pos = 2;
	for (; pos <= argc-2 && ps < tar; pos += 1) {
		// the coin currently being considered
	        int cc = atoi(argv[pos]);
		// number of current coin type to be used
		int j = 0;
		for (; cc <= tar-ps; j += 1) {
			ps += cc;
		}
		numcoin[pos-2] = j;
	}
	
	while (pos <= argc-2) {
		numcoin[pos-2] = 0;
		pos += 1;
	}
	
	if (ps != tar)	std::cout << "Impossible" << std::endl;
	else {
		for (int i = 0; i <= nt - 1; i++) {
			if (numcoin[i] != 0) 
				std::cout << numcoin[i] << " x " << argv[i+2] << "\n";
		}
	}
	return 0;
}

/* tests
small test
mpossible
~/cs246/a02$ g++ -o makeChange.out makeChange.cpp

test case1: all of the coin values are used at least once
~/cs246/a02$ ./makeChange.out 3 8 3 1 13
1 x 8
1 x 3
2 x 1

test case2: some of the coin values not used
~/cs246/a02$ ./makeChange.out 3 8 3 1 9
1 x 8
1 x 1

~/cs246/a02$ ./makeChange.out 2 6 3 1 9
1 x 6
1 x 3

test case3: impossible
~/cs246/a02$ ./makeChange.out 2 8 3 9
Impossible
*/
