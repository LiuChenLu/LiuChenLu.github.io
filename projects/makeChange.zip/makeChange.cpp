////////////////////////////////////////////////////////////////////
//
// 
// Liu Chen Lu
//
// makeChange.cpp
//
// makeChange.app -number of coin types -list of coin values in 
//	decreasing order -target/total
//
// given a denomination of coins from standard input, makes
// 	change for a given value using the minimum number of coins
// 	using greedy algorithm (assumed to work)
//
////////////////////////////////////////////////////////////////////

#include <iostream>
int main() {
	
	// number of types of coins
	int nt;
	std :: cin >> nt;
	
	int values [nt];
	for (int i = 0; i < nt; i += 1) {
		std :: cin >> values[i];
	}
	
	// the target value
	int target;
	std :: cin >> target;
	
	// partial sum of coins
	int ps = 0;
	
	// array of number of each type of coin used
	int numcoin [nt];

	// the position of the current coin being considered
	int pos = 0;
	for (; pos < nt && ps < target; pos += 1) {
	        int cc = values[pos];
		// number of current coin type to be used
		int j = 0;
		for (; cc <= target-ps; j += 1) {
			ps += cc;
		}
		numcoin[pos] = j;
	}
	
	while (pos < nt) {
		numcoin[pos] = 0;
		pos += 1;
	}
	
	if (ps != target) std::cout << "Impossible" << std::endl;
	else {
		for (int i = 0; i <= nt - 1; i++) {
			if (numcoin[i] != 0) 
				std::cout << numcoin[i] << " x " << values[i] << "\n";
		}
	}
	return 0;
}

/* tests
small test
mpossible
~/cs246/a02$ g++ -o makeChange.out makeChange.cpp

test case1: all of the coin values are used at least once
~/cs246/a02$ ./makeChange.out < 3 8 3 1 13
1 x 8
1 x 3
2 x 1

test gase2: some of the coin values not used
~/cs24d a02$ ./makeChange.out < 3 8 3 1 9
1 x 8
1 x 1

~/cs246/a02$ ./makeChange.out < 3 6 3 1 9
1 x 6
1 x 3

test case3: impossible
~/cs246/a02$ ./makeChange.out < 2 8 3 9
Impossible
*/
