#ifndef __RATIONALNUMBER_H__
#define __RATIONALNUMBER_H__

#include <iostream>
#include <cstdlib>
#include <climits>

#define minint INT_MIN
#define maxint INT_MAX

class Rationalnumber {
	//friend void intializer ();
    friend bool operator==( Rationalnumber l, Rationalnumber r );
    friend bool operator!=( Rationalnumber l, Rationalnumber r );
    friend bool operator<( Rationalnumber l, Rationalnumber r );
    friend bool operator<=( Rationalnumber l, Rationalnumber r );
    friend bool operator>( Rationalnumber l, Rationalnumber r );
    friend bool operator>=( Rationalnumber l, Rationalnumber r );

    friend Rationalnumber operator+( Rationalnumber l, Rationalnumber r );
    friend Rationalnumber operator-( Rationalnumber l, Rationalnumber r );
    friend Rationalnumber operator*( Rationalnumber l, Rationalnumber r );
    friend Rationalnumber operator/( Rationalnumber l, Rationalnumber r );

    friend std::istream &operator>>( std::istream &is, Rationalnumber &r );
    friend std::ostream &operator<<( std::ostream &os, Rationalnumber r );

    int num, denom;                        // implementation

  private:
  
  // finds the gcd of a and b using the euclidean method and returns a positive numberas their gcd
  // CANNOT HANDLE a = b = minint !!! (my code ensures that they do not get passed in)
	static unsigned int gcd (int a, int b) {
		Rationalnumber::gcdi += 1;
		if ( a<0 ) a=-a;
		if ( b<0 ) b=-b;

		unsigned int ua = static_cast<unsigned int> (a);
		unsigned int ub = static_cast<unsigned int> (b);
		
		// in case of a = minint, -a = a, so the unsigned int cast will not be well defined
		// mathamatically, absolute(minint) = maxint + 1
		if ( a<0 ) { 
			ua = static_cast<unsigned int>(maxint) + 1;
		}
		if ( b<0 ) {
			ub = static_cast<unsigned int>(maxint) + 1;
		}

		int t;
		while ( ub != 0 ) {
			t = ub;
			ub = ua % ub; // modulos
			ua = t;
		} 
		
		return static_cast<int>(ua); 
		// ua cannot be more than maxint + 1. unless a = b = minint or a = 0 and b = minint, it will be no more than maxint
	}

	// casting overload to double
	operator double() const {
		double d;
		int num = this->numerator();
		int denom = this->denominator();
		d = static_cast<double>(num) / static_cast<double>(denom); 
		// note, cannot put static_cast<double>(this->numerator()) because it will try to cast the overloaded function to double
		return d;
	}
	
  // global statics gathered for the number of calls to
	static int gcdi; //calls to gcd
	//rational-number objects created by regular constructors
	static int con;
	//rational-number objects created by copy constructors
	static int copy;
	//rational-number objects created destroyed by the destructor
	static int des;
	//assignments to rational-number objects
	static int assn;
	//relational/equality operations between rational-number objects
	static int rel;
	//addition/subtraction operations between rational-number objects
	static int add,sub;
	//multiplication/division operations between rational-number objects
	static int mul, div;
	//input/output operations on rational-number objects
	static int in, out;

  public:                                  // interface routines
    Rationalnumber() : num(0), denom(1) {
		Rationalnumber::con += 1;
		//intentionally empty
	}
    Rationalnumber( int n ) : num(n), denom(1) {
		Rationalnumber::con += 1;
		// intentionally empty
	}
    Rationalnumber( int n, int d ){ // no initialization in creation since it is more clear to do it in the body of the code
		
		Rationalnumber::con += 1;
		if (d == 0) {
			std::cerr<<"The denominator cannot be zero. Make sure you do not divide by zero."<<std::endl;
			exit (EXIT_FAILURE);
		}
		else if ( n == 0) { // does not need to be here really, but it's more clear
			this->num = 0;
			this->denom = 1;
		}
		else if ( n == d ) { // this condition is to prevent n=d=intmin being passed into gcd
			this->num = this->denom = 1 ;
		}
		else {
			int g = gcd (n, d);
			Rationalnumber::gcdi -= 1;

			this->num = n/g;
			this->denom = d/g;

			// make the numerator positive and denominator negative
			if ( this->denom < 0 ) {
				this->num = -1*this->num;
				this->denom = -1*this->denom;
			}
		}
		
		/*here's a joke:
		Two guys met in the middle of the desert. One was carrying a
		car door, the other an umbrella. The one with the car door 
		said to the guy with the umbrella, "Why are you carrying 
		that umbrella around, it isn't going to rain in the desert?"
		To which the guy with the umbrella replies, "Yeah�, but it 
		keeps me out of the sun! By the way, why are you carrying 
		around that car door, you don�t even have a car to go with 
		it� The guy with the car door says, "yeah, well at least if
		I get too hot from the sun I can just roll down the window!"
		*/
	}
	
	// copy constructor
    Rationalnumber( const Rationalnumber &c ) : num(c.num) , denom (c.denom){
		Rationalnumber::copy += 1;
		// intentionally empty
	}
	
    ~Rationalnumber(){
		Rationalnumber::des += 1;
		//since all are basic types with no pointers, no explicit
		//destruction is needed
	}

	// return numerator
    int numerator() const {
		return this->num;
	}
	// set numerator to n; return previous numerator
    int numerator( int n ) {
		int prevnum = this -> num;
		
		int g = Rationalnumber::gcd(n, this->denom );
		Rationalnumber::gcdi -= 1;
		this->num = n/g;
		this->denom = denom/g;

		return prevnum;
	}
	
	// return denominator
    int denominator() const {
		return this->denom;
	}

	// set denominator to d; return previous denominator
    int denominator( int d ){
		if (d == 0) {
			std::cerr<<"The denominator cannot be zero. Make sure you do not divide by zero."<<std::endl;
			exit (EXIT_FAILURE);
		}
		int prevdenom = this->denom;

		// there can be problem cases when d = minint.
		if (this->num == minint && d == minint) { // special case to prevent minint and minint being passed into gcd
			this->num = this->denom = 1;
		} else if (d < 0) {
			int g = Rationalnumber::gcd( d, this->num );
			Rationalnumber::gcdi -= 1;
			this->denom = -(d/g);
			this->num = -(num/g);
		} else {
			int g = Rationalnumber::gcd(d, this->num );
			Rationalnumber::gcdi -= 1;
			this->denom = d/g;
			this->num = num/g;
		}

		return prevdenom;
	}

	// unary negation, newrat is returned because we do not want to modify the original rational number
    Rationalnumber operator-(){
		Rationalnumber newrat;
		Rationalnumber::con -= 1;
		newrat.num = -1 * this->num;
		newrat.denom = this->denom;
		return newrat;
	}
	
	; // assignment
    Rationalnumber &operator=( const Rationalnumber &r ) {
		Rationalnumber::assn += 1;
		this->num = r.num;
		this->denom = r.denom;
		return *this;
	}

	// prints a bunch of things
    static void statistics(){
		std::cerr << "gcd:" << gcdi <<
			"\n\tObject Stats:\n\t\tcon:"<< con <<
			"\n\t\tcopy:"<< copy <<
			"\n\t\tdes:"<< des <<
			"\n\tOperation stats:\n\t\tassn:"<< assn <<
			"\n\t\trel:"<< rel <<
			"\n\t\tadd:"<< add <<
			"\n\t\tsub:"<< sub <<
			"\n\t\tmul:"<< mul <<
			"\n\t\tdiv:"<< div <<
			"\n\t\tin:"<< in<<
			"\n\t\tout:"<< out << std::endl;
	}
}; // Rationalnumber

extern bool operator==( Rationalnumber l, Rationalnumber r );
extern bool operator!=( Rationalnumber l, Rationalnumber r );
extern bool operator<( Rationalnumber l, Rationalnumber r );
extern bool operator<=( Rationalnumber l, Rationalnumber r );
extern bool operator>( Rationalnumber l, Rationalnumber r );
extern bool operator>=( Rationalnumber l, Rationalnumber r );

extern Rationalnumber operator+( Rationalnumber l, Rationalnumber r );
extern Rationalnumber operator-( Rationalnumber l, Rationalnumber r );
extern Rationalnumber operator*( Rationalnumber l, Rationalnumber r );
extern Rationalnumber operator/( Rationalnumber l, Rationalnumber r );

extern std::istream &operator>>( std::istream &is, Rationalnumber &r );
extern std::ostream &operator<<( std::ostream &os, Rationalnumber r );

#endif // __RATIONALNUMBER_H__
