#include "Rationalnumber.h"
#ifndef minint
#define minint INT_MIN
#endif

#ifndef maxint
#define maxint INT_MAX
#endif

int main () {
	// testing basic functionalities involving edge cases
	Rationalnumber r = Rationalnumber(1,maxint);
	Rationalnumber r2 = Rationalnumber(minint , 2);
	Rationalnumber r3 = Rationalnumber(maxint, 2);
	Rationalnumber r4 = Rationalnumber(maxint,maxint);
	Rationalnumber r5 = Rationalnumber(minint, minint);
	Rationalnumber r6 = Rationalnumber(0,minint); // okay i know i only need one to test assignment, but the syntax highlighting is so pretty!
	Rationalnumber r7 (2, maxint);
	Rationalnumber r8 (1, maxint - 1);
	Rationalnumber r9 (minint, maxint);
	Rationalnumber r10(-1, maxint);
	//Rationalnumber r7(2,0);

	std::cout << r/r << "=1/1\n";
	std::cout << r2 + r2 << "=minint/1\n";
	std::cout << r3 + r3 << "=maxint/1\n";
	std::cout << r4 <<"=1/1\n";
	std::cout << r5 <<"=1/1\n";
	std::cout << r6 <<"=0/1\n";
	bool b = r<r8;
	std::cout << b <<"=true\n"; // this shows that double is enough to differentiate
	std::cout << r8 + r8 << "=2/maxint-1\n";
	std::cout << r + r << "=2/maxint\n";
	std::cout << r9 - r9 << "=0/1\n";
	std::cout << r10-r9 << "=-(minint+1)/maxint=1/1\n";
	std::cout << r9-r10 << "=(minint+1)/maxint=-1/1\n";
	std::cout << r9/r9 <<"=1/1\n";
	std::cout << r + r7 << "=3/maxint\n";
	std::cout << r3 * r7 << "=1/1\n";
	std::cout << r10*r3 <<"=-1/2\n";

	// testing random non edge cases.
	Rationalnumber n (1, 6);
	Rationalnumber n1 (1, 3);
	Rationalnumber n2 (3,5);
	Rationalnumber n3 (4,8);
	Rationalnumber n4 (1,2);
	Rationalnumber in;

	std::cin>>in;

	std::cout<<n + n1 << "=1/2\n";

	std::cout << n2 + n3 << "=11/10\n";
	b = ( n2 + n3 != n2 + n4 );
	std::cout << b << "=false\n"; //3/5 + 4/8 != 3/5 + 1/2

	std::cout<<in<<std::endl;

	Rationalnumber::statistics();
	
	return 0;
}