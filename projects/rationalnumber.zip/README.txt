*************************************************
Description
*************************************************
Rationalnumber implements the numeric type rational number with as much stability as possible without ever casting up to 64 bit integer (or implimenting my own 64 bit integer class). It is capable of handling MOST cases when the final fraction of the operation/s does not have overflow. 

To prevent overflow of large numerator/denominator values during arithmetic operations, each rational number is reduced immediately when it is 
created. 

The program terminates if a rational number is created with a denominator equal to zero. 

Rational numbers are printed in the form "numerator/denominator", e.g., 3/4.

Negative rational numbers have only one minus sign, which is always associated with the numerator, e.g., -3/4. 

0 is represented as 0/1


*************************************************
Creating your own .exe file
*************************************************
There is a .exe file included in this zip file, but if you want to make your own version of it, you can:

1.Go into bash or cywin
2.navegate to the current directory
3.run "makefile"

Feel free to modify the makefile.

*************************************************
Usage
*************************************************
1.in a bash shell, navigate to the directory the .exe file is in
2.run "./rational.exe"

There is no REPL loop, this is meant to be used like a library class. Any function you want to test out is need to be put into rationalmain.cc
There are some sample test cases in rationalmain.cc already. You can edit/delete them how ever you like.

*************************************************
Known bugs
*************************************************
Rationalnumbers cannot handle certain case of addition.

For example, say you want e/f = a/b + c/d, where e and f are not overflows. Let g=gcd(b,d). Addition cannot produce e and f properly if ( a*(d/g) + b*(c/g) ) or ( d*(c/g) ) overflows unless e=0.

If I assume addition does not overflow, subtraction cannot overflow.

Other operations that do not depend on addition will never overflow in intermediate steps if the final answer does not have overflow
	1. Multiplication and division in and of themselves are stable 
		note: division is dependant on multiplication
	3. Reassignment of numerators and denominators are independant of addition.
	4. GCD will never overflow unless the value it is suppose to return is an overflow