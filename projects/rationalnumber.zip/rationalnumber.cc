#include <iostream>
#include <cstdlib>
#include "rationalnumber.h"
#include <climits>

#ifndef minint
#define minint INT_MIN
#endif

#ifndef maxint
#define maxint INT_MAX
#endif

// initialize all static variable in Rationalnumber

int Rationalnumber::gcdi=0;
int Rationalnumber::con=0;
int Rationalnumber::copy=0;
int Rationalnumber::des=0;
int Rationalnumber::assn=0;
int Rationalnumber::rel=0;
int Rationalnumber::add=0;
int Rationalnumber::sub=0;
int Rationalnumber::mul=0;
int Rationalnumber::div=0;
int Rationalnumber::in=0;
int Rationalnumber::out=0;

bool operator==( Rationalnumber l, Rationalnumber r ){
	Rationalnumber::rel += 1;
	return ( l.numerator()==r.numerator() && l.denominator()==r.denominator() );
}

bool operator!=( Rationalnumber l, Rationalnumber r ){
	return !(l==r);
}

bool operator<( Rationalnumber l, Rationalnumber r ){
	Rationalnumber::rel += 1;
	double dl = static_cast<double>(l);
	double dr = static_cast<double>(r);
	return dl < dr; // the precision of double floating points is enough to determine whether l or r is larger

}
bool operator<=( Rationalnumber l, Rationalnumber r ){
	Rationalnumber::rel -= 1; // < and = will both increment rel, so i have to decrement it once
	return ( (l<r) || (l==r) );
}

bool operator>( Rationalnumber l, Rationalnumber r ){
	return !(l<=r); // does not need to increment rel since <= increments it
}
bool operator>=( Rationalnumber l, Rationalnumber r ){
	return !(l<r); // does not need to increment rel
}

// the only way to ensure that I do not have any overflow is to cast to 64 bit integer
Rationalnumber operator+( Rationalnumber l, Rationalnumber r ){
	Rationalnumber::add += 1;
	
	int newnum, newdenom, g;
	
	if ( l==r ) { // it can now handle intmax/2 + intmax/2
		if (l.denominator() % 2 == 0 ) {
			newnum = l.numerator();
			newdenom = l.denominator()/2;
		} else {
			newnum = 2*l.numerator();
			newdenom = l.denominator();
		}
	} else if ( l.denominator() != r.denominator() ){
		// only multiply by the smallest possible number to get a 
		// common denominator between l and r
		g = Rationalnumber::gcd (l.denominator(), r.denominator());
		Rationalnumber::gcdi -= 1;
		newnum = l.numerator() * ( r.denominator()/g ) + r.numerator() * ( l.denominator()/g );
		
		// newdenom cannot be negative since r.denominator(), gcd, l.denominator() are all positive
		newdenom = ( r.denominator()/g ) * l.denominator(); 
	} else {
		newnum = l.numerator() + r.numerator() ;
		newdenom = l.denominator();
	}
	
	if ( newnum == 0 ) {
		Rationalnumber::con -= 1;
		return Rationalnumber (0,1);
	}
	// reduce to lowest common denom
	g = Rationalnumber::gcd(newnum, newdenom);
	Rationalnumber::gcdi -= 1;
	
	Rationalnumber::con -= 1;
	return Rationalnumber( newnum/g , newdenom/g );
}

// implimented similar to operator+
Rationalnumber operator-( Rationalnumber l, Rationalnumber r ){
	Rationalnumber::sub += 1;
	
	//int newnum, newdenom, g;
	
	Rationalnumber::rel -= 1;
	if (l==r){
		Rationalnumber::con -= 1;
		Rationalnumber r(0);
		return r;
	} else if (r.numerator() != minint ) {
		Rationalnumber::add -= 1;
		Rationalnumber::assn -= 1;
		r = -r;
		return l+r;
	} else if (l.numerator() != minint) { // do -(b-a)
		Rationalnumber::add -= 1;
		Rationalnumber::assn -= 1;
		l = -l;
		return -(r+l);
	} else { // l.numerator == r.numerator == minint and l!=r
		//int olddenom = l.denominator();
		Rationalnumber rn =( 1,r.denominator() );
		Rationalnumber::con -= 1;
		r.numerator( -(r.numerator() + 1) ); //make it work.
		return r+l+rn;

		// i am doing
		// -a/b - -c/d = -a/b + c/d = -a/b + (c-1)/d + 1/d
	}

}

// implimented similar to operator* but not symetrical since the range of the denom is 1 to maxint but the range of the num is maxint to minint
// flipping the sign of num and denom can cause overflow since -minint is overflow
Rationalnumber operator/( Rationalnumber l, Rationalnumber r ) {
	Rationalnumber::div += 1;

	if (r.numerator() != minint){
		Rationalnumber::mul -= 1;
		Rationalnumber::con -= 1;
		Rationalnumber newr (r.denominator(), r.numerator());
		return l*newr;
	} if (l.numerator() != minint){
		// do (r/l)^-1
		Rationalnumber::mul -=1;
		Rationalnumber::con -= 3;
		Rationalnumber::assn -= 1;
		Rationalnumber newr (l.denominator(), l.numerator()); // constructor called
		Rationalnumber newr2 = newr*r; // constructor called, multiplication called
		Rationalnumber newr3 (newr2.denominator(), newr2.numerator()); // consructor called
		return newr3;
	}
	else /*(r.denominator() == minint && l.denominator() == minint)*/ {
		int newnum, newdenom;
		Rationalnumber::con -= 1;
		newnum = r.denominator();
		newdenom = l.denominator();
		
		int g = Rationalnumber::gcd(newnum, newdenom);
		Rationalnumber::gcdi -= 1;
		newnum = newnum/g;
		newdenom = newdenom/g;

		Rationalnumber newr (newnum, newdenom);
		return newr;
	}
}

Rationalnumber operator*( Rationalnumber l, Rationalnumber r ) {
	Rationalnumber::mul += 1;
	Rationalnumber::gcdi -= 3;
	Rationalnumber::con -= 1; 
	
	// make sure i multiply by the smallest things possible
	int gcd1 = Rationalnumber::gcd (l.numerator(), r.denominator());
	int gcd2 = Rationalnumber::gcd (r.numerator(), l.denominator());
	int newnum = (l.numerator()/gcd1) * (r.numerator()/gcd2);
	int newdenom = (l.denominator()/gcd2) * (r.denominator()/gcd1); 
	// newdenom cannot be negative or zero since gcds and denoms are
	// positive
	
	// normalize 0
	if ( newnum == 0 ) {
		return Rationalnumber (0,1);
	}
	
	// i'm pretty sure gcd3 will always be 1 anyways.
	int gcd3 = Rationalnumber::gcd (newnum,newdenom);

	return Rationalnumber ( newnum/gcd3 , newdenom/gcd3 );
}

// outputs the rational number as numerator/denominator
std::ostream &operator<<( std::ostream &os, Rationalnumber r ){
	Rationalnumber::out += 1;
	os << r.numerator() << '/' <<  r.denominator();
	return os;
}

// user input: numerator whitespace denominator
// denominator must not be zero
std::istream &operator>>( std::istream &is, Rationalnumber &r ){
	Rationalnumber::in += 1;
	int newnum, newdenom;
	is >> newnum ; 
	is >> newdenom;
	if (newdenom < 0 ) {
		newnum = -1*newnum;
		newdenom = -1*newdenom;
	}

	Rationalnumber::gcdi -= 1;
	int g = Rationalnumber::gcd (newnum, newdenom);
	
	r.numerator(newnum/g);
	r.denominator(newdenom/g);
	return is;
}
