#ifndef __UMPIRE_H__
#define __UMPIRE_H__

#include "PRNG.h"
#include "player.h"
#include "potato.h"

class Umpire {
    // YOU MAY ADD MEMBERS
  public:
    Umpire( Player::PlayerList &players );
	virtual ~Umpire();
	void start();
  protected:
	Player::PlayerList* group;
	int mashed; // 1 means the next potato is mashed, 0 the next potato fried
	int set; // tracks how many times potatos have been tossed
	Mashed* mash;
	Fried* fry;
};

#endif

/* because umpire has a member called fry
       .  ."|
      /| /  |  _.----._ 
     . |/  |.-"        ".  /|
    /                    \/ |__
   |           _.-"""/        /
   |       _.-"     /."|     /
    ".__.-"         "  |     \
       |              |       |
       /_      _.._   | ___  /
     ."  ""-.-"    ". |/.-.\/
    |    0  |    0  |     / |
    \      /\_     _/    "_/  not sure if useful comment
     "._ _/   "---"       |   or just commenting for the sake of comments
     /"""                 |  
     \__.--                |_ 
       )          .        | ". 
      /        _.-"\        |  ".
     /     _.-"             |    ".  
    (_ _.-|                  |     |"-._.
      "    "--.             .J     _.-'
              /\        _.-" | _.-'
             /  \__..--"   _.-'
            /   |      _.-'         
           /| /\|  _.-'
          / |/ _.-'
         /|_.-'  
       _.-'
*/
