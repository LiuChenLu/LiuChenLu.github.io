#include "potato.h"
#include "PRNG.h"
#include <iostream>


extern PRNG p;

Potato::Potato() : tick(0), maxtick(0) {}

bool Potato::realcountdown() {
	this->tick -= 1;
	// if tick was at 1 before the subtraction, the potato has exploded in your hand
	if (this->tick == 0) return true;
	else return false;
}

Mashed::Mashed(unsigned int maxTicks) {
	this->maxtick = maxTicks;
	this->reset();
} 

void Mashed::reset(){
	this->tick = p(1, this->maxtick);
	std::cout<<"  Mashed POTATO will go off after "<< this->tick <<" tosses"<<std::endl;
}

bool Mashed::countdown() {
	return this->realcountdown();
}

Fried::Fried (unsigned int maxTicks) {
	this->maxtick = maxTicks;
	this->tick = maxTicks;
	if (maxTicks > 5) {
		this->maxtick = 5;
	}
	this->tick = this->maxtick;
	std::cout<<"  Fried POTATO will go off after "<<this->tick<<" tosses"<<std::endl;
}

void Fried::reset(){
	this->tick = this->maxtick;
	this->tick = this->maxtick;
	std::cout<<"  Fried POTATO will go off after "<<this->tick<<" tosses"<<std::endl;
}

bool Fried::countdown() {
	return this->realcountdown();
}
