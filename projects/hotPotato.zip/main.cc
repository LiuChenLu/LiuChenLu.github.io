/*
Simulate a game of Hot Potato. The game consists of an umpire and a
number of different kinds of players. The umpire starts a set by tossing
a particular kind of hot potato to a player. What makes the potato hot
is the timer inside it. The potato is then tossed among the players 
until the timer goes off. A player never tosses the potato to 
themselves. The player holding the potato when the timer goes off is 
eliminated. The potato is then given back to the umpire, who resets the
timer in the potato, and begins the game again with the remaining
players, unless only one player remains, which the umpire declares the 
winner.

The executable program is named hotpotato and has the following shell interface:
  hotpotato [ players [ seed ] ]
players is the number of players in the game and must be between 2 and 20, inclusive. If no value for players is specified, use the value 5. seed is the seed for the random number generator, in the range [1. .N], so it is possible to generate repeatable output. If no value for seed is specified, the random number generator is initialized with an arbitrary seed value (e.g., current time, process id, etc.). Both arguments must be checked for correct type and range. The main program creates the umpire, the players, alternating with either a LRPlayer or RNPlayer (starting with an LRPlayer) and player identifiers from 0 to players-1, and the list holding all the players. It then begins a match by calling Umpire::start. 
*/

#include <stdlib.h>
#include <iostream>

// for the rand() function
#include <cstdlib> 

#include "player.h"
#include "potato.h"
#include "umpire.h"

#define _maxplayers_ 20
#define _minplayers_ 2
#define _minseed_ 1

// global variables
int numplayer=5;
int seed=1;

void setseed () {
	do {
		seed = rand();
	} while (seed == 0);
}

PRNG p (seed) ; // range 1 to rand_max, i avoided doing rand()+1 because rand_max is a little broken...

// bad number of players
void bnop (int num) {
	
	std::cerr << "Invalid number of players entered: " << num << ". The number of players must be between "<<_minplayers_<<" and "<<_maxplayers_<<", inclusive." << std::endl;
	exit (EXIT_FAILURE);

}

// bad seed
void bs (int seed) {
	std::cerr << "Invalid seed entered: " << seed << ". The seed must be between "<<_minseed_<<" and unsigned int max, inclusive." << std::endl;
	exit (EXIT_FAILURE);
}

// initializes the playerlist
Player::PlayerList* initialize (int length) {
	std::cout<< length << " players in the match"<<std::endl;
	Player::PlayerList* players = new Player::PlayerList();
	
	for (int i = 0; i < length ; i++) {
		
		// since we want alternative random and left/right players, starting with left/right player, all the even valuse of i will correspond to a l/r player
		if ( i%2 == 0 ) {
			(*players)[i] = new LRPlayer (i, *players);
		} else {
			(*players)[i] = new RNPlayer (i, *players);
		}
	}
	return players;
}

int main ( int argc, char* argv[]) {
	
	//std::cout<<argc<<std::endl;

	// setting up numplayer and seed
	switch (argc-1) {
		case 0 : setseed(); p.seed(seed); break;
		case 1 : numplayer = atoi(argv[1]); 
			if (numplayer > _maxplayers_ || numplayer < _minplayers_) {
				bnop (numplayer);
			}
			setseed(); p.seed(seed);
			break;
		case 2 : numplayer = atoi (argv[1]);
			if (numplayer > _maxplayers_ || numplayer < _minplayers_) {
				bnop (numplayer);
			}
			seed = atoi(argv[2]);
			if (seed < _minseed_) {
				bs(seed);
			}
			p.seed(seed);
			break;
		default:
			std::cerr<<"Incorrect usage. Hotpotato has interface: \n hotpotato [ players [ seed ] ]"<<std::endl;
			exit (EXIT_FAILURE);
	}
	
	Player::PlayerList* players = initialize (numplayer);
	
	Umpire u(*players);
	
	//play the game and dont stop until there is only one survivor.
	for (; numplayer>1 ; numplayer--) {
		u.start();
	}
	// there is now only one player in players, so calling begin (or end if you're a glass half empty kinda guy) will return the sole survivor
	Player::PlayerList::iterator it;
	it = (*players).begin();
	int winner = (*it).first;
	
	std::cout << winner<< " wins the Match!" << std::endl;

	delete (*it).second;

	delete players;
	return 0;
}

// okay i know consistant output makes marking easy...it takes too much away from this assignment. map has fast access, insertion and deletion. if it wasnt for the constraint that it needs to be consisant (ie i cant just keep regenerating prn until i get a good one, which would be linear time only near the end of the game) it is the perfect data structure for this assignment. this isnt teaching good coding techniques/strategies. please for the love of god consider revising this assignment for the future.
// ps, i know as a ta its not your fault that this assignment is not well designed. can you pass the word along to whom ever has control over this?
