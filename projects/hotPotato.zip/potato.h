#ifndef __POTATO_H__
#define __POTATO_H__

#include "PRNG.h"

class Potato {
  protected:
	int tick;
	int maxtick;
	// countdown should be a non virtual function since it would be implimented *exactly* the same in both children, but since i'm not allowed to declare new public functions in this assignment, I've taken the liberty to poke a little loop hole.
	bool realcountdown();
	Potato();
	
  public:
	// called by empire to reinitialize the timer to reuse the potato
	virtual void reset() = 0;        // must be defined in derived class
	
    // called by players
	// true -> time gone off
	// each countdown call is one tick of the clock
	virtual bool countdown() = 0;    // must be defined in  derived class
};

//The mashed potato chooses a random value in the range [1,maxTicks] for the number of ticks.
class Mashed : public Potato {
  public:
    Mashed( unsigned int maxTicks = 10 );
    void reset();
    bool countdown();
};

//The fried potato is set with maximum ticks of 5
class Fried : public Potato {
    // YOU MAY ADD MEMBERS
  public:
    Fried( unsigned int maxTicks = 10 );
    void reset();
    bool countdown();
};
#endif
