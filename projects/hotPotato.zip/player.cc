#include "player.h"
#include "PRNG.h"
#include <iostream>
extern PRNG p;
extern int numplayer;

/*
i respect your decision to make the empirer delete the player as they are removed, but i think its stupid.
// deletes all the entries in a PlayerList
void end (Player::PlayerList &players) {
	PlayerList::iterator it = players.begin();
	while ( it != players.end() ) {
		delete *it;
	}
}
*/

// defining all the functions in Player
Player::Player (unsigned int id, Player::PlayerList &players) : 
	group(&players), id(id) { 
	// knock knock
	//   who's there?
	// who let the dogs out, who
}

unsigned int Player::getId() {
	return this->id;
}

// define functions in RNPlayer
RNPlayer::RNPlayer ( unsigned int id, Player::PlayerList &players) : Player(id, players) {
}

// tossing the hot potato to another player
// if the potato explodes, return the player's if the potato does not explode, return the player the potato was tossed to
unsigned int RNPlayer::toss (Potato &potato){
	//std::cerr <<"RNPlyer about to toss" << std::endl;
	// if the potato goes off
	if (potato.countdown()){
		//std::cerr<<"RNPlayer about to be eliminated"<<std::endl;
		return this->getId();
	} 
	
	int tossto;
	Player::PlayerList::iterator it;

	int nextid;
	// toss it to a new player
	//std::cerr <<"got here" << std::endl;
	do {
		tossto = p ( numplayer - 1 );
		it=(*(this->group)).begin();
		for (; tossto>0; tossto--) {
			it++;
		}
		nextid = (*it).first;
	} while(nextid == this->getId());
	return nextid;
}

// define functions in LRPlayer
LRPlayer::LRPlayer (unsigned int id, Player::PlayerList &players) : Player(id, players), left(1) {
}

unsigned int LRPlayer::toss (Potato &potato){
	//std::cerr<<"lrplayer abuot to toss"<<std::endl;
	// if the potato goes off
	if (potato.countdown()){
		return this->getId();
	} 
	
	// toss it to a new player
	int nextplayer;
	
	Player::PlayerList::iterator it;
	it = (*group).find(this->getId());
	if (this->left == 1) { // tossing left
		
		if (it == (*group).begin()) {
			it = -- (*group).end();
			nextplayer = (*it).first;
		} else {
			it --;
			nextplayer = (*it).first;
		} 
	} else { // tossing right
		if (it == -- (*group).end()) {
			nextplayer = (*((*group).begin())).first;
		} else{
			it ++;
			nextplayer = (*it).first;
		}
	}
	//std::cout<<"lrp player "<<this->getId()<<" tossed left"<<std::endl;
				
	this->left = (this->left + 1) % 2;
	return nextplayer;
}
