#ifndef __PLAYER_H__
#define __PLAYER_H__

#include <map>
#include "potato.h"

using std::map;

class Player {
  public:
    typedef map<int,Player*> PlayerList;
    
	Player( unsigned int id, Player::PlayerList &players );
	
    virtual unsigned int getId();
    
	virtual unsigned int toss( Potato &potato ) = 0; // must be defined in derived class
  
  protected:
	
	Player::PlayerList* group;
	
	unsigned int id;
};

// choose any random player to recieve the potato by generating a random number until it is not the current player
class RNPlayer : public Player {
  public:
    RNPlayer( unsigned int id, Player::PlayerList &players );
    unsigned int toss( Potato &potato );
};

// alternately choose between the player on the left or the right, starting with the player on the left
class LRPlayer : public Player {
  public:
    LRPlayer( unsigned int id, Player::PlayerList &players );
    unsigned int toss( Potato &potato );
  protected:
	// 1 if next toss should be left, 0 if right
	int left; 
};

#endif
