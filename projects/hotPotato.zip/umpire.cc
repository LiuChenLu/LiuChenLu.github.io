#include "umpire.h"
#include "PRNG.h"
#include "player.h"
#include "potato.h"
#include <map>
#include <iostream>

extern PRNG p;
extern int numplayer;

Umpire::Umpire (Player::PlayerList &players) : mashed(1), set(1)  {
	this->group = &players;
	this->mash = new Mashed();
	this->fry = new Fried();
}

Umpire::~Umpire (){
	delete this->mash;
	delete this->fry;
}

// given a player id, RoA returns either R for random player or A for alternating player
char RoA (int id) {
	if (id%2 == 1){
		//std::cout<<"about to return R"<<std::endl;
		return 'R';
	} else {
		//std::cout<<"about to return A"<<std::endl;
		return 'A';
	}
}

void remainingplayers (Player::PlayerList* group) {

	Player::PlayerList::iterator it;

	//Internally, map containers keep their elements ordered by their keys from lower to higher , therefore begin returns the element with the lowest key value in the map, it++ returns the next highest, end returns the highest.
	for (it=(*group).begin(); it != group->end(); it++) {
		std::cout << (*it).first;
	}
}

void Umpire::start(){
	
	Potato* potato;
	if (this->mashed==1) {
		potato = this->mash;
	} else {
		potato = this->fry;
	}

	// if this is the first toss, dont make another mashed potato
	if (this->set != 1) {
		potato->reset();
	}

		int thisplayer = p(0,numplayer-1);
	
	Player::PlayerList::iterator it = (*group).begin();
	for (int i=thisplayer; i>0 ; i--) {
		it++;
	}
	thisplayer = (*it).first;

	int prevplayer; 

	// print some information about this set
	std::cout<<"Set "<<this->set<<"-\tUser (";
	if (this->mashed==1) {
		std::cout<<"mashed";
	} else {
		std::cout<<"fried";
	}
	std::cout<<") [";
	remainingplayers(this->group);
	std::cout << "]: ";

	//int seedtracker;

	// eliminate a player
	while (true) {
	//std::cerr<<"start loop"<<std::endl;
		prevplayer = thisplayer;

		Player* player;
		player = (*group)[prevplayer];
		
		//seedtracker = p.seed();
		thisplayer = player->toss(*potato);
		//std::cerr<<"past assignment of this player"<<std::endl;

		if (prevplayer==thisplayer){
			//p.seed(seedtracker);
			break;
		}
		//std::cout<<going to RoA"<<std::endl;
		std::cout<<RoA(prevplayer)<<"("<<prevplayer<<"), ";
		//std::cerr << "got here" << std::endl;
	}

	std::cout<<RoA(prevplayer)<<"("<<prevplayer<<"). Eliminated: "<<prevplayer<<std::endl;

	// remove the storage for thisplayer
	//std::cerr<<"got here"<<std::endl;

	delete (*group)[thisplayer];
	(*group).erase(thisplayer);
	
	this->set ++;
	this->mashed = (this->mashed + 1 ) % 2 ;
}
